<?php

use App\Http\Controllers\Admin\ContactController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProductManagement\CategoryController;
use App\Http\Controllers\Admin\ProductManagement\ProductController;
use App\Http\Controllers\Admin\QuoteController;
use App\Http\Controllers\Admin\UserManagement\PermissionController;
use App\Http\Controllers\Admin\UserManagement\RoleController;
use App\Http\Controllers\Admin\UserManagement\UserController;
use App\Http\Controllers\GalleryCategoryController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\User\ClientController;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('user.about');
// });

Route::get('/', [ClientController::class, 'index'])->name('home');
Route::get('about', [ClientController::class, 'about'])->name('about');
Route::get('service', [ClientController::class, 'service'])->name('service');
Route::get('product', [ClientController::class, 'product'])->name('product');
Route::get('gallery_images', [ClientController::class, 'gallery'])->name('gallery');
Route::get('product-details/{name}', [ClientController::class, 'product_details'])->name('product_details');
Route::get('contact', [ClientController::class, 'contact'])->name('contact');
Route::post('contact-store', [ClientController::class, 'contactstore'])->name('contact.store');
Route::post('/submit-quote', [ClientController::class, 'store'])->name('submit.quote');
Route::get('career', [ClientController::class, 'career'])->name('career');
Route::post('career/apply', [ClientController::class, 'careerApply'])->name('career.apply');

Route::get('/category/{name}', [ClientController::class, 'categoryProducts'])->name('category.products');
// Route::get('/product-details/{name}', [ClientController::class, 'ProductDetails'])->name('productsdetails');

Route::get('login', [DashboardController::class, 'login'])->name('login');
Route::post('login-validate', [DashboardController::class, 'login_validate'])->name('admin.login-validate');
Route::get('logout-admin', [DashboardController::class, 'logout'])->name('admin.logout');

// forgot password
Route::get('forgot_password', [DashboardController::class, 'forgot_password'])->name('forgot_password');
Route::post('forgot-validate', [DashboardController::class, 'forgot_validate'])->name('forgot_validate');

// otp password
Route::get('otp-verify', [DashboardController::class, 'otp_verify'])->name('otp.verify');
Route::post('otp-validate', [DashboardController::class, 'otp_validate'])->name('otp_validate');
// Route::post('otp-resend', [DashboardController::class, 'otp_resend'])->name('otp_resend');
Route::post('otp-resend', [DashboardController::class, 'otp_resend'])->name('otp_resend');

// reset password
Route::get('reset_password', [DashboardController::class, 'reset_password'])->name('reset_password');
Route::post('reset-validate', [DashboardController::class, 'reset_validate'])->name('reset_validate');




Route::middleware(['auth'])->group(function () {

    Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');

    // Permisssion
    Route::get('permission-index', [PermissionController::class, 'index'])->name('permission.index');
    Route::get('/get-permissions', [PermissionController::class, 'getPermissions'])->name('permissions.get');
    Route::get('permission-create', [PermissionController::class, 'create'])->name('permission.create');
    Route::post('permission-store', [PermissionController::class, 'store'])->name('permission.store');
    Route::get('permission-edit/{id}', [PermissionController::class, 'edit'])->name('permission.edit');
    Route::PUT('permission-update/{id}', [PermissionController::class, 'update'])->name('permission.update');
    Route::delete('permission-delete/{id}', [PermissionController::class, 'delete'])->name('permission.delete');

    //role
    Route::get('role-index', [RoleController::class, 'index'])->name('role.index');
    Route::get('get-roles', [RoleController::class, 'getRoles'])->name('role.get');
    Route::get('role-create', [RoleController::class, 'create'])->name('role.create');
    Route::post('role-store', [RoleController::class, 'store'])->name('role.store');
    Route::get('role-edit/{id}', [RoleController::class, 'edit'])->name('role.edit');
    Route::PUT('role-update/{id}', [RoleController::class, 'update'])->name('role.update');
    Route::delete('role-delete/{id}', [RoleController::class, 'delete'])->name('role.delete');


    //user
    Route::get('user-index', [UserController::class, 'index'])->name('user.index');
    Route::get('get-user', [UserController::class, 'getusers'])->name('user.get');
    Route::get('user-create', [UserController::class, 'create'])->name('user.create');
    Route::post('user-store', [UserController::class, 'store'])->name('user.store');
    Route::get('user-edit/{id}', [UserController::class, 'edit'])->name('user.edit');
    Route::PUT('user-update/{id}', [UserController::class, 'update'])->name('user.update');
    Route::delete('user-delete/{id}', [UserController::class, 'delete'])->name('user.delete');

    //category
    Route::get('category-index', [CategoryController::class, 'index'])->name('category.index');
    Route::get('get-category', [CategoryController::class, 'getCategory'])->name('category.get');
    Route::get('category-create', [CategoryController::class, 'create'])->name('category.create');
    Route::post('category-store', [CategoryController::class, 'store'])->name('category.store');
    Route::get('category-edit/{id}', [CategoryController::class, 'edit'])->name('category.edit');
    Route::PUT('category-update/{id}', [CategoryController::class, 'update'])->name('category.update');
    Route::delete('category-delete/{id}', [CategoryController::class, 'destroy'])->name('category.delete');

    //product
    Route::get('product-index', [ProductController::class, 'index'])->name('product.index');
    Route::get('get-product', [ProductController::class, 'getProduct'])->name('product.get');
    Route::get('product-create', [ProductController::class, 'create'])->name('product.create');
    Route::post('product-store', [ProductController::class, 'store'])->name('product.store');
    Route::get('product-edit/{id}', [ProductController::class, 'edit'])->name('product.edit');
    Route::PUT('product-update/{id}', [ProductController::class, 'update'])->name('product.update');
    Route::delete('product-delete/{id}', [ProductController::class, 'destroy'])->name('product.delete');
    Route::delete('/product-image/{id}', [ProductController::class, 'destroy_product_image'])->name('product_image.delete');


    // Image Category
    Route::get('image-category', [GalleryCategoryController::class, 'index'])->name('image_category.index');
    Route::get('get-image-category', [GalleryCategoryController::class, 'getImageCategory'])->name('image_category.get');
    Route::get('image-category-create', [GalleryCategoryController::class, 'createCategory'])->name('image_category.create');
    Route::post('image-category-store', [GalleryCategoryController::class, 'storeCategory'])->name('image_category.store');
    Route::get('image-category/{id}', [GalleryCategoryController::class, 'editCategory'])->name('image_category.edit');
    Route::PUT('image-category/{id}', [GalleryCategoryController::class, 'updateCategory'])->name('image_category.update');
    Route::delete('image-category-delete/{id}', [GalleryCategoryController::class, 'destroy_Category'])->name('image_category.delete');




    // Gallery Image Routes

    Route::get('gallery', [GalleryController::class, 'index'])->name('gallery.image.index');
    Route::get('gallery/get', [GalleryController::class, 'getGallery'])->name('gallery.image.get');
    Route::get('gallery/upload', [GalleryController::class, 'createImage'])->name('gallery.image.create');
    Route::post('gallery/upload/store', [GalleryController::class, 'store'])->name('gallery.image.store');
    Route::get('/gallery/{category}/images', [GalleryController::class, 'editGallery'])->name('gallery.image.edit');
    Route::put('gallery/{id}/update', [GalleryController::class, 'updateGallery'])->name('gallery.image.update');
    Route::delete('gallery/{id}/delete', [GalleryController::class, 'delete_Gallery'])->name('gallery.image.delete');
    Route::delete('/gallery-image/{id}/destroy', [GalleryController::class, 'destroy_Gallery'])->name('gallery-image.destroy');


    // Route::get('gallery/category/create', [GalleryCategoryController::class, 'createCategory']);
    // Route::post('gallery/category/store', [GalleryCategoryController::class, 'storeCategory']);
    // Route::get('gallery/image/create', [GalleryController::class, 'createImage']);
    // Route::post('gallery/image/store', [GalleryController::class, 'storeImage'])->name('gallery.storeImage');

    // Quote
    Route::get('quote-index', [QuoteController::class, 'index'])->name('quote.index');
    Route::get('getquote', [QuoteController::class, 'getquote'])->name('quote.get');
    Route::delete('quote-delete/{id}', [QuoteController::class, 'delete'])->name('quote.delete');


    // contact
    Route::get('contact-index', [ContactController::class, 'index'])->name('contact.index');
    Route::get('getPermissions', [ContactController::class, 'getPermissions'])->name('contact.getPermissions');
    Route::delete('contact-delete/{id}', [ContactController::class, 'delete'])->name('contact.delete');

    // Career Categories
    Route::get('admin/career-categories', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'index'])->name('admin.career_category.index');
    Route::get('admin/get-career-categories', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'getCategory'])->name('admin.career_category.get');
    Route::get('admin/career-category-create', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'create'])->name('admin.career_category.create');
    Route::post('admin/career-category-store', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'store'])->name('admin.career_category.store');
    Route::get('admin/career-category-edit/{id}', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'edit'])->name('admin.career_category.edit');
    Route::put('admin/career-category-update/{id}', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'update'])->name('admin.career_category.update');
    Route::delete('admin/career-category-delete/{id}', [\App\Http\Controllers\Admin\CareerCategoryController::class, 'destroy'])->name('admin.career_category.delete');

    // Career Jobs
    Route::get('admin/career-jobs', [\App\Http\Controllers\Admin\CareerJobController::class, 'index'])->name('admin.career_job.index');
    Route::get('admin/get-career-jobs', [\App\Http\Controllers\Admin\CareerJobController::class, 'getJob'])->name('admin.career_job.get');
    Route::get('admin/career-job-create', [\App\Http\Controllers\Admin\CareerJobController::class, 'create'])->name('admin.career_job.create');
    Route::post('admin/career-job-store', [\App\Http\Controllers\Admin\CareerJobController::class, 'store'])->name('admin.career_job.store');
    Route::get('admin/career-job-edit/{id}', [\App\Http\Controllers\Admin\CareerJobController::class, 'edit'])->name('admin.career_job.edit');
    Route::put('admin/career-job-update/{id}', [\App\Http\Controllers\Admin\CareerJobController::class, 'update'])->name('admin.career_job.update');
    Route::delete('admin/career-job-delete/{id}', [\App\Http\Controllers\Admin\CareerJobController::class, 'destroy'])->name('admin.career_job.delete');

    // Career Applications
    Route::get('admin/career-applications', [\App\Http\Controllers\Admin\CareerApplicationController::class, 'index'])->name('admin.career_application.index');
    Route::get('admin/get-career-applications', [\App\Http\Controllers\Admin\CareerApplicationController::class, 'getApplication'])->name('admin.career_application.get');
    Route::get('admin/career-application-download/{id}', [\App\Http\Controllers\Admin\CareerApplicationController::class, 'downloadResume'])->name('admin.career_application.download');
    Route::delete('admin/career-application-delete/{id}', [\App\Http\Controllers\Admin\CareerApplicationController::class, 'destroy'])->name('admin.career_application.delete');
});
