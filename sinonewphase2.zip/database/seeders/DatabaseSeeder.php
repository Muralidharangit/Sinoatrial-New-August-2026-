<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            PermissionTableSeeder::class,
            RolesTableSeeder::class,
            UserTableSeeder::class,
            CareerDataSeeder::class,
        ]);
    }
}
